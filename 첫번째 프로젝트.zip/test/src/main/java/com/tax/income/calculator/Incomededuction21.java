package com.tax.income.calculator;

	public class Incomededuction21 {
		
		public double inde21(double salary1) {
			
	
			return (salary1/12 * (0.0065)) + (salary1/12 * (0.0312)*(1.0369));
}


	}