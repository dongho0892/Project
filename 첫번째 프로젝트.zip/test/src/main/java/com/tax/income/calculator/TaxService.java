package com.tax.income.calculator;

public class TaxService {

	public static void main(String[] args) {
		
	}
}
